<?php
include'include/functions.php';
include'include/connection.php'; //imports the connection to this class
//if theres no username session; the user gets referred back to the Login. Much more secure.
if(!($_SESSION['username'])) {
    header("Location: login.php");
}
//Once the user logs out, the session is destroyed and referred back to the Login.

if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("Location: login.php");
}
if($_POST) {
    //gets all of the data and puts it here.
    $startingpoint = mysqli_real_escape_string($database,$_POST['startingpoint']);
    $destination = mysqli_real_escape_string($database, $_POST['destination']);
    $traveltime = mysqli_real_escape_string($database, $_POST['traveltime']);
    $days = mysqli_real_escape_string($database, $_POST['days']);
    $lift = mysqli_real_escape_string($database, $_POST['lift']);
    $cost = mysqli_real_escape_string($database, $_POST['cost']);
    $car = mysqli_real_escape_string($database, $_POST['car']);
    $id = mysqli_real_escape_string($database, $_POST['id']);

    if(empty( $_POST['startingpoint'] && $_POST['destination'] && $_POST['traveltime']
             && $_POST['days'] && $_POST['lift'] && $_POST['cost'] && $_POST['car']))
    {
        $errormessage = "Please fill in your details"; //refill any empty textboxes
    } else if (!(is_numeric($days))) {
        $errormessage = "You need to put the number of days. Use the numbers for it, not letters";
    } else if (!(is_numeric($cost))) {
        $errormessage = "You need to the percentage you ideally would like to share. Use the numbers for it!";
    } else if(preg_match("^[A-Za-z0-9_-]+$", $startingpoint)) {
        $errormessage = "You need to type in a Location for Starting Point. Please try again!";
    } else if(preg_match("^[A-Za-z0-9_-]+", $destination)) {
        $errormessage = "You need to type in a Location for Destination. Please try again!";
    } elseif (ctype_alnum($_POST['car']) != true) {
        $errormessage = "You need to type in a car.";
    } else {
        //updates all the information using the sql statement and puts it into the database
        $sql = "UPDATE members SET startingpoint='$startingpoint', destination='$destination', days='$days', 
			lift='$lift', cost='$cost', car='$car' WHERE id=$id";
        if(mysqli_query($database, $sql)) {
            header("Location: index.php");
        }
    }
}
?>
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb">

    <head>
        <!-- Navigation Bar -->
        <div class="navigation">
            <a class="home" href="index.php">Home</a>
            <a class="logout" href="index.php?logout='1'">Logout</a>
            <a class="contactus" href="ContactUs.php">Contact Us</a>
            <a class="addTable" href="addTable.php">Add Post</a>
            <a class="viewpost" href="search.php">Search Posts</a>

        </div>
        <?php echo $errormessage; //message output here. ?>
        <title>Edit Data</title>
        <link rel="stylesheet" type="text/css" href="style.css">
        <script type="text/javascript" src="validation.js"></script>

    </head>
    <body>
        <div class="header">
            <h2>Edit Post</h2>
        </div>
                <!-- HTML is all below -->
        <form action="edit.php" method="post" onSubmit="validationAddPost()">
            <div class="container">
                <div class="input-group">	
                    <input type="hidden" name="id" value='<?php $id = $_GET['id']; echo $id;?>' readonly="readonly">
                </div>
                <div class="input-group">
                    <label>Starting Point</label>
                    <input type="text" name="startingpoint" value="<?php $startingpoint = $_GET['sp']; echo $startingpoint;?>">
                </div>
                <div class="input-group">
                    <label>Destination</label>
                    <input type="text" name="destination" value='<?php $destination = $_GET['ds']; echo $destination;?>'>
                </div>
                <div class="input-group">
                    <label>Days</label>
                    <input type="text" name="days" value='<?php $days = $_GET['day']; echo $days;?>'>
                </div>
                <div class="input-group">
                    <label>Travel Time</label>
                    <input type="text" name="traveltime" value='<?php $traveltime = $_GET['tt']; echo $traveltime;?>'>
                </div>
                <div class="input-group">
                    <label> Lift: </label>
                    <input type="radio" name="lift" value="Provide Lift" <?php echo ($_GET['lt'] =="Provide Lift")?"checked":''?>>Provide Lift
                </div>
                <div class="input-group">
                    <input type="radio" name="lift" value="Obtain Lift" <?php echo ($_GET['lt'] =="Obtain Lift")?"checked":''?>>Obtain Lift
                </div>
                <div class="input-group">
                    <label>What sort of cost sharing do you have in mind?</label> 
                    <input type="text" name="cost" value='<?php $cost = $_GET['ct']; echo $cost;?>'>
                </div>
                <div class="input-group">
                    <label>What sort of car do you have?</label>
                    <input type="text" name="car" value='<?php $car = $_GET['cr']; echo $car;?>'>
                </div>
                <div class="input-group">
                    <input type="submit" name="Submit" value="Edit">
                </div>
            </div>
        </form>
    </body>
</html>
