<?php
include'include/functions.php';
include'include/connection.php';
//gets the code that is typed in.
$actCode=mysqli_real_escape_string($database,trim($_POST['codeConfirm']));
//gets the session that is typed in.
$confirmationCode = $_SESSION['code'];
$username = $_SESSION['username'];
if($_POST){
    if (strlen( $_POST['codeConfirm']) > 5 || strlen($_POST['codeConfirm']) < 5)
    {
        $error = 'Incorrect Length for the Code'; //length must be 5 or it shows this message
    }
    elseif (ctype_alnum($_POST['codeConfirm']) != true)
    {
        $error = 'Code must be alpha numeric';
    } elseif((mysqli_real_escape_string($database,trim($_POST['codeConfirm']))) != $_SESSION['code']) {
        $error = 'Sorry, the Code entered was incorrect!'; // checks if it is wrong 
    }				
    else {
        if(mysqli_query($database, 'UPDATE users SET confirm="1" WHERE  username="'.$_SESSION['username'].'"'))
        {
            $error = "Thank You. Your email has been confimed and you may now login";
            header('Location: login.php');
            //if all correct goes to the login page.
        } else {
            //if wrong with database, it shows this message.
            $error = "It is wrong. Try again";
        }
    }	
}
?>
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb">

    <head>
        <title>Email Confirmation</title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
        <div class="header">
            <h2>Email Confirmation</h2>
        </div>
        <!-- All HTML details are below -->
        <form method="post" action="regconfirm.php">
            <div class="container">
                <div class="input-group">
                    <label>Please type the code in here</label>
                    <input type="text"name="codeConfirm" id="codeConfirm" maxlength="5" placeholder="Enter code">
                </div>
                <div class="input-group">
                    <input type="submit"  name="confirm" value="Confirm">
                </div>
                <?php echo $error; //shows message output?>
            </div>
        </form>
    </body>
</html>