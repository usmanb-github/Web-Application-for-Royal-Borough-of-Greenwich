<?php 	
include'include/functions.php'; 
//if theres no username session; the user gets referred back to the Login. Much more secure.
if(!($_SESSION['username'])) {
    header("Location: login.php");
}
//Once the user logs out, the session is destroyed and referred back to the Login.
if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("Location: login.php");
}
?>
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb">

    <head>
        <!-- mobile view -->
        <meta name="viewport" content="width=device-width, initial-scale=1"/>

        <div class="navigation">
            <a class="home" href="index.php">Home</a>
            <a class="logout" href="index.php?logout='1'">Logout</a>
            <a class="contactus" href="ContactUs.php">Contact Us</a>
            <a class="addTable" href="addTable.php">Add Post</a>
            <a class="viewpost" href="search.php">Search Posts</a>
        </div>
        <title>Add Data</title>	
        <link rel="stylesheet" type="text/css" href="style.css">
        <script type="text/javascript" src="validation.js"></script>


    </head>
    <body>
        <div class="header">
            <h2>Add Post</h2>
            <h4>This page is where you can add a post. Fill in the details below!</h4>
        </div>
        <form method="post" action="addTable.php" onSubmit="validationAddPost()" enctype="multipart/form-data">
            <!-- details for html are shown below -->
            <div class="container">
                <div class="input-group">
                    <label>Starting Point</label>
                    <input type="text" name="startingpoint" id="startingpoint" placeholder="e.g. London"/>
                </div>
                <div class="input-group">
                    <label>Destination</label>
                    <input type="text" name="destination" id="destination" placeholder="e.g. Manchester"/>
                </div>
                <div class="input-group">
                    <label>How many days?</label>
                    <input type="text" name="days" id="days" placeholder="e.g. 1"/>
                </div>
                <div class="input-group">
                    <label>Travel Time</label>
                    <input type="datetime-local" id="traveltime" name="traveltime"/>
                </div>
                <label> What sort of lift you need? </label>
                <div class="input-group">
                    <input type="radio" name="lift" id= "lift" value="Provide Lift"/> <label>Provide Lift </label>
                </div>
                <div class="input-group">
                    <input type="radio" name="lift" id="lift" value="Obtain Lift"/><label>Obtain Lift</label>
                </div>
                <div class="input-group">
                    <label>What sort of cost sharing do you have in mind? (Preferably in %) </label>
                    <input type="text" name="cost" id="cost" placeholder="e.g. 10"/>
                </div>
                <div class="input-group">
                    <label>What sort of car do you have? (If no car, specify what travel you using)</label>
                    <input type="text" name="car" id="car" placeholder="e.g. Audi"/>
                </div>
                <div class="input-group">
                    <label for="userFile">Small image to upload: </label>
                </div>
                <div class="input-group">
                    <input type="file" size="40" name="userFile" id="userFile"/>	
                </div>
                <div class="input-group">
                    <label for="altText">Description of image</label>
                </div>
                <div class="input-group">
                    <input type="text"  name="altText" id="altText"  placeholder="Enter the description of the image" />
                </div>
                 <div class="input-group">
                <input type="submit"  name="submit" value="Submit">
                </div>
            </div>
        </form>
        <?php 
include'include/connection.php';
session_start();	
//Image upload is used from http://stuweb.cms.gre.ac.uk/~ha07/web/PHP/imageUpload.html
if($_POST) {
//details for what is going to be typed in is shown here.
    $startingpoint = mysqli_real_escape_string($database, $_POST['startingpoint']);
    $destination = mysqli_real_escape_string($database, $_POST['destination']);
    $traveltime = mysqli_real_escape_string($database, $_POST['traveltime']);
    $days = mysqli_real_escape_string($database, $_POST['days']);
    $lift = mysqli_real_escape_string($database, $_POST['lift']);
    $cost = mysqli_real_escape_string($database, $_POST['cost']);
    $car = mysqli_real_escape_string($database, $_POST['car']);
    $usernames = $_SESSION['username'];

    //if empty show the message.
    if(empty( $_POST['startingpoint'] && $_POST['destination'] && $_POST['traveltime']
             && $_POST['days'] && $_POST['lift'] && $_POST['cost'] && $_POST['car']))
    {
        $errormessage = "Please fill in your details"; //refill any empty textboxes
    }
    //validation for all the textboxes are below.
    else if(preg_match("^[A-Za-z'0-9_-]+$", $startingpoint)) {
        $errormessage = "You need to type in a Location for Starting Point. Use letters not numbers";
    } else if(preg_match("^[A-Za-z'0-9'_-]+", $destination)) {
        $errormessage = "You need to type in a Location for Destination. Use letters not numbers";
    }  else if (!(is_numeric($days))) {
        $errormessage = "You need to put the number of days. Use the numbers for it, not letters";
    } else if (!(is_numeric($cost))) {
        $errormessage = "You need to the percentage you ideally would like to share. Use the numbers for it!";
    } elseif (ctype_alnum($_POST['car']) != true) {
        $errormessage = "You need to type in a car.";
    } else if (!empty($_POST['altText'])){
        //if the preg match doesnt match, it shows the message e.g. document are not allowed. Only images (jpeg, png, x-png and gifs)
        if ( !preg_match( '/gif|png|x-png|jpeg/', $_FILES['userFile']['type']) ) {
            $errormessage = 'Only browser compatible images allowed';
        }
        //only more than 9 characters allowed to be put in.
        else if ( strlen($_POST['altText']) < 9 ) {
            $errormessage = 'Please provide meaningful alternate text';
        }
        //file no bigger than 16384
        else if ( $_FILES['userFile']['size'] > 16384 ) {
            $errormessage = 'Sorry, file too large';
            // Connects to database and if not, shows the message
        } else if ( !($database)) {
            $errormessage = 'Error connecting to database';
            // Copy image file into a variable
        } else if ( !($handle = fopen ($_FILES['userFile']['tmp_name'], "r")) ) {
            $errormessage = 'Error opening temp file';
        }
        else if ( !($image = fread ($handle, filesize($_FILES['userFile']['tmp_name']))) ) {
            $errormessage = 'Error reading temp file';
        } else {
            fclose ($handle);
            // Commit image to the database
            $image = mysqli_real_escape_string($database, $image);
            $alt = $_POST['altText'];
            $imageType = $_FILES['userFile']['type'];
            $imageName = $_FILES['userFile']['name'];
            //gets all the stuff and puts it into the database using the query
            $sql = "INSERT INTO members (username, startingpoint, destination, traveltime, days, lift, cost, car, type, name, alt, img) 
	   VALUES('$usernames','$startingpoint','$destination','$traveltime','$days','$lift','$cost','$car', '$imageType', '$imageName', '$alt', '$image')";
            if (mysqli_query($database, $sql)) {
                $errormessage = 'Image successfully copied to database';
            }			
        }
    } else if (empty($_POST['altText'])) {
        ///gets all the stuff and puts it into the database using the query without image by using SQL Injection
        $stmt = $database->prepare("INSERT INTO members (username, startingpoint, destination, traveltime, days, lift, cost, car) VALUES(?,?,?,?,?,?,?,?)");
        $stmt->bind_param('ssssssss', $usernames, $startingpoint, $destination, $traveltime, $days, $lift, $cost, $car);
        $stmt->execute();
        $errormessage = "Successfully Added";

    }
}
        ?>
    </body>
    <?php echo $errormessage; ?>
</html>

