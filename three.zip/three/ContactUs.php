<?php
include('include/functions.php');
include('include/connection.php');

if($_POST) {
    //if empty the message is shown.
    if(empty($_POST['subject'] && $_POST['comment'])) {
        $messageOutput = "It is empty. Please fill it in.";
    } else if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $errormessage = "Wrong email method, try again"; //email validation
    } else {
        //gets all the stuff to be put into the database..uses SQL Injection
        $username = $_SESSION['username'];
        $email = $_POST['email'];
        $subject = $_POST['subject'];
        $messages = $_POST['comment'];
        $stmt = $database->prepare("INSERT INTO contact (username, email, subject, message) 
        VALUES (?,?,?,?)");
        $stmt->bind_param('ssss', $username, $email, $subject, $messages);
        if ($stmt->execute()) {
            $messageOutput = "Message has been sent";
            $emailSent = "From: $email";
            $emailFrom = "ub2232e@greenwich.ac.uk";
            mail($emailFrom ,$subject, $messages, $emailSent);
            //sends to the person saying you have admitted the query.
            $automatedMessage = "Hello, 
        You have submitted your message. You will recieve a reply within two or three days. Do not reply to this email as you are not expected to get a reply straight away.


        Message sent: $messages
        Username: $username
        Email: $email
        From: Royal Borough of Greenwich";
            //sends another email to myself to reply to the query
            mail($email ,'Enquiry', $automatedMessage, "From: ub2232e@greenwich.ac.uk");
        }
    }
}
?>
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb">
    <head>
        <!-- Navigation Bar below -->
        <div class="navigation">
            <a class="home" href="index.php">Home</a>
            <a class="logout" href="index.php?logout='1'">Logout</a>
            <a class="contactus" href="ContactUs.php">Contact Us</a>
            <a class="addTable" href="addTable.php">Add Post</a>
            <a class="viewpost" href="search.php">Search Posts</a>
        </div>
        <title>Contact us</title>
        <!-- All details for HTML are below-->
        <?php echo $messageOutput; //output message here?>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
        <div class="header">
            <h1>Contact us</h1>
            <h3>We are here happy to help if you have any enquiries!</h3>
            <h4>Please fill out the form below to submit the enquiry!</h4>
        </div>
        <form method="post" action="ContactUs.php">
            <div class="container">
                <div class="input-group">
                    <label> Subject </label>
                    <input type="text" name="subject" id="Subject" placeholder="Enter subject here">
                </div>
                <div class="input-group">
                    <label> Email </label>
                    <input type="text" name="email" id="email" placeholder="Enter Email here">
                </div>
                <div class="input-group">
                    <label>Message:- </label>
                </div>
                <div class="input-group"> 
                    <textarea rows="4" cols="50" name="comment" placeholder="Enter your message here......"></textarea>
                </div>
                <div class="input-group">
                    <input type="submit"  name="submit" value="Submit">
                </div>
                <h3>If you have any other issues, please use the details below to contact us if it is an emergency</h3>
                <h3>Email: ub2232e@greenwich.ac.uk</h3>
                <h3>Contact number: 07561473247</h3>
            </div>
        </form>
    </body>
</html>