<?php
include'include/functions.php';
include'include/connection.php';
 
if ($_POST) {
    //all details for register are below
    $username = $_POST['username'];
    $captcha = $_POST['captcha'];
    $session = $_SESSION["captchacode"];
    if(empty( $_POST['username'] && $_POST['password'] && $_POST['email'] && $_POST['captcha']))
    {
        $errormessage = "Please fill in your details."; //if empty message is shown
    } 
    elseif (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $errormessage = "Wrong email method, try again"; //wrong email, it shows message
    }	 
    elseif (!($captcha == $_SESSION["captchacode"])) 
    {
        $errormessage = "Wrong Code Entered"; //wrong captcha, its shows message

    }
    elseif (ctype_alnum($_POST['username']) != true)
    {
        $errormessage = "Username does not match. Please try again with letters and numbers"; //if not numbers or letters, its shown
    }	 
    else {
        //enters into the database using SQL Injection.
        $stmt = $database->prepare("INSERT INTO users (username, email, password, confirm, code) 
			VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param('sssis', $username, $email, $passwordHash, $zero, $confirmationCode);
        //creates a random code. Same code used from Captcha.php
        $charArray = array('a','b','c','d','e','f','g','h','j','k','m','n','p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','G','H','J','K','L','M','N','P','Q','R','T','U','V','W','X','Y','Z','2','3','4','6','7','8','9');
        shuffle($charArray);
        $confirmationCode = $charArray[0];
        for ($i=1; $i<5; $i++) $confirmationCode .= '' . $charArray[$i];

        $username=mysqli_real_escape_string($database,$_POST['username']);
        $password=mysqli_real_escape_string($database,$_POST['password']);
        $email=mysqli_real_escape_string($database,$_POST['email']);
        $zero = "0";
        //enters a more secure password hash. When entered, it creates a differnet hash when the same password is entered.
        $options = [
            'c' => 11,
            's' => mcrypt_create_iv(22, MCRYPT_DEV_URANDOM),
        ];
        $passwordHash = password_hash($password, PASSWORD_BCRYPT, $options);
        //http://php.net/manual/en/function.password-hash.php used from here. Adapted accordingly.
        $sql = "SELECT * FROM users WHERE username='$username'";
        //checks for duplicate username
        if(!(mysqli_num_rows(mysqli_query($database, $sql)) <= 0)) {
            $errormessage = "User exists, try another username.";
        }	
        else
        {		
            //executes using SQL Injection
            $stmt->execute();
            $message = "Hello,
				 Please use the code below to verify email address and activate account.
				 Username: $username 
				 Activation Code: $confirmationCode
				 Thank you,
				 Greenwich Borough";
            //sends email
            mail($email ,'Account activation code', $message, "From: ub2232e@greenwich.ac.uk");
            //and sends it to the regconfirm after its all done
            $errormessage = "Please confirm your email address to activate your account.";
            $_SESSION['username'] = $username;
            $_SESSION['code'] = $confirmationCode;
            header('Location: regconfirm.php');				 
        }
    }
}
?>
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb">
    <head>
        <!-- mobile view used from https://www.w3schools.com/html/html_responsive.asp -->
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <div class="navigation">
            <a class="home" href="navigation.php">Home</a>
            <a class="login" href="login.php">Login</a>
            <a class="register" href="register.php">Register</a>
        </div>
        <title>Registration</title>
        <link rel="stylesheet" type="text/css" href="style.css">
        <script type="text/javascript" src="validation.js"></script>
    </head>
    <body>
        <div class="header">
            <h2>Register</h2>
        </div>
        <form method="post" action="register.php"  onSubmit="validationAddPost()">
            <div class="container">
                <div class="input-group">
                    <label>Username</label>
                    <input type="text"  value="<?php if(isset($_POST["username"])) echo $_POST["username"]; ?>" 
                           name="username" id="username" placeholder="Enter Username" onblur="checkTextField(this);">
                </div>
                <div class="input-group">
                    <label>Email</label>
                    <input type="email" value="<?php if(isset($_POST["email"])) echo $_POST["email"]; ?>" 
                           name="email" id="email" placeholder="Enter Email">
                </div>
                <div class="input-group">
                    <label>Password</label>
                    <input type="password" value="<?php if(isset($_POST["password"])) echo $_POST["password"]; ?>"
                           name="password" id="password" placeholder="Enter Password">	
                </div>
                <div class="input-group">
                    <label> Enter the digits </label>
                    <input name="captcha" id="captcha" type="text" placeholder="Enter code" onClick=content(this)>
                    <img src="captcha.php" />
                </div>
                <div class="input-group">
                    <input type="submit"  name="registerBtn>">
                </div>
                <?php echo $errormessage;?>

            </div>
        </form>
    </body>
</html>