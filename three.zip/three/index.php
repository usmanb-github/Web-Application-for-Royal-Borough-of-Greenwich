<?php
include'include/connection.php';
include'include/functions.php';
ob_start();
//if theres no username session; the user gets referred back to the Login. Much more secure.
if(!($_SESSION['username'])) {
    header("Location: login.php");
}
//Once the user logs out, the session is destroyed and referred back to the Login.
if (isset($_GET['logout'])) {
  //  if(isset($_COOKIE['user'])) {
    //    $userCookie = $_COOKIE['user'];
      //  setcookie('user', $userCookie, time()-1);
    //}
    session_destroy();
    unset($_SESSION['username']);
    header("Location: login.php");
}
?>
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb">

    <head>
        <div class="navigation">
            <a class="home" href="index.php">Home</a>
            <a class="logout" href="index.php?logout='1'">Logout</a>
            <a class="contactus" href="ContactUs.php">Contact Us</a>
            <a class="addTable" href="addTable.php">Add Post</a>
            <a class="viewpost" href="search.php">Search Posts</a>
        </div>
        <title>Home</title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>

        <div class="header">
            <h2>Home Page</h2>
            <h4>This is the page where you can see your posts. You can choose to edit and delete them!</h4>
        </div>

        <?php  if (isset($_SESSION['username'])) :?>
        <p>Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>
        <?php endif //shows using a session which users account is logged in as a message. So, e.g. it would be welcome Username and would be different eacht time 
        ?>
        <table class="header" align="center" width="100%">
            <tr align="center">
                <td>Starting Point</td>
                <td>Destination</td>
                <td>Travel Time</td>
                <td>Days</td>
                <td>Lift</td>
                <td>What sort of cost sharing do you have in mind?</td>
                <td>What sort of car do you have?</td>
                <td>Image</td>
            </tr>
            <?php
    $usernameSession = $_SESSION['username'];
        $result = mysqli_query($database, "SELECT * FROM members WHERE username='$usernameSession'"); //shows the table using the Username. Each post represents there own. So they can delete and edit their own post whilst others cannot view other users post. Only through search where they have the available sources to only view it. Not delete it.
        while($res = mysqli_fetch_array($result)) {
            //table is shown below
            echo "<tr>";
            echo "<td>".$res['startingpoint']."</td>";
            echo "<td>".$res['destination']."</td>";
            echo "<td>".$res['traveltime']."</td>";
            echo "<td>".$res['days']."</td>";
            echo "<td>".$res['lift']."</td>";
            echo "<td>".$res['cost']."</td>";
            echo "<td>".$res['car']."</td>";
            echo '<td><img src="getImage.php?id='.$res['id'].'" alt="'. $res['alt']. '" title="'. $res['name'].'"width="175" height="200"/><td>';
            echo "<td><a href=\"edit.php?id=$res[id]&&sp=$res[startingpoint]&&ds=$res[destination]&&tt=$res[traveltime]&&lt=$res[lift]&&day=$res[days]&&ct=$res[cost]&&cr=$res[car]\">Edit Post</a></td>";
            echo "<td><a href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete Post<a/></td>";
            echo "<td><a href=\"imageUpload.php?id=$res[id]\">Replace Image</a></td>";
            echo "<td><a href=\"deleteImage.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete Image</a></td>";
           
        }
            ?> 
        </table>				
    </body>
</html>
