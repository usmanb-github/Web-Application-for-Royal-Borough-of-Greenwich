<?php 
include'include/connection.php';
include'include/functions.php';
ob_start();
?>

<head>
    <!-- mobile view used from https://www.w3schools.com/html/html_responsive.asp -->
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <!-- Linked style for the page -->
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <!-- Navigation Bar link -->
    <div class="navigation">
        <a class="home" href="navigation.php">Home</a>
        <a class="login" href="login.php">Login</a>
        <a class="register" href="register.php">Register</a>
    </div>
    
    <!-- The Introduction Paragraph -->
    <div style="height:80px;
                width: 250px; padding-left:60px; font-size: 20px; text-align: center;">
        <h2>Royal Borough of Greenwich</h2>
        <p> Royal Borough of Greenwich provides a site to provide information to other daily commutes. 
            The site provides information to authorised and non authorised users. 
            Unauthorised users can be able to search through the posts that only have images. 
            Without images, unauthorised users cannot be able to view the post that they have searched.
            If the user wants to view the post, they have to go through authentication in login.
            You can be able to the whole post once the user is successful in login.
            If users are unable to login, they have to make an account and verifiy it before using their account.
            Once the user has logged in, they can be able to post their own daily commutes and journeys.
      </p>
    </div>

    <?xml version="1.0" encoding="UTF-8"?>
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb">
        <head>
                <!-- Title for the page -->
            <title>Royal Borough of Greenwich</title>
            <link rel="stylesheet" type="text/css" href="style.css">
        </head>
        <body>
            <form action="navigation.php" method="post">
                    <!-- Form page -->
                <div class="container">
                    <h1> Search </h1>
                    <h3> You can view posts only with images</h3>
                    <h4> Use the the details below to search for any places you would like to see!</h4>
                    <div class="input-group">
                        <label> Starting Point:-  </label>
                        <input type="search" name="startingpoint" value="<?php $userCookie = $_COOKIE['startingpoint']; echo $userCookie;?>" placeholder="e.g. London">
                    </div>
                    <div class="input-group">
                        <label> Destination:-  </label>
                        <input type="search" name="destination" value="<?php $userCookie = $_COOKIE['destination']; echo $userCookie;?>"placeholder="e.g. Manchester">
                    </div>
                    <div class="input-group">
                        <label> Date and Time:-  </label>
                        <input type="datetime-local" name="traveltime" value="<?php $userCookie = $_COOKIE['traveltime']; echo $userCookie;?>">
                    </div>
                      <div class="input-group">
                 <input type="checkbox" name="cookielaw"><label>This site uses cookies. Regulations require us to gain your consent before continuing for this page. Tick this to accept.</label>
                </div>
                    <div class="input-group">
                    <input type="submit"  name="search" value="Search">
                        <?php echo $output; ?>
                    </div>
                </div>
                <div style="margin-top:350px; 
                            margin-left:10px; text-align: center;">
                    <h3> Results</h3>
                </div>
            </form>


            <?php
            if(isset($_POST['search'])){
                //links the post
                $sp = $_POST['startingpoint'];
                $dt = $_POST['destination'];
                $traveltime = $_POST['traveltime'];

                $searchsp=preg_replace("#[^0-9a-z]#i"," ", $sp);
                $searchdt=preg_replace("#[^0-9a-z]#i"," ", $dt);
                $searchdate=preg_replace(' ', '', $traveltime);

            //query used for the table shown.  
                $query = mysqli_query($database,'SELECT * FROM members WHERE startingpoint LIKE "%'.$searchsp.'%" AND destination LIKE "%'.$searchdt.'%" AND traveltime LIKE "%'.$searchdate.'%"  AND type IS NOT NULL');
                $count = mysqli_num_rows($query); 
                
                if ($count == 0) {
                    //if number of rows do not match, puts the output as no search result
                    $output = "There was no search result.";
                      if(isset($_POST['cookielaw'])) {
                    //cookies set when cookielaw is ticked 
                        setcookie('startingpoint', $sp, time()+60*60*7);
                        setcookie('destination', $dt, time()+60*60*7);
                        setcookie('traveltime', $traveltime, time()+60*60*7);
                    }
                }
                else {
                    if(isset($_POST['cookielaw'])) {
                    //cookies set when cookielaw is ticked 
                        setcookie('startingpoint', $sp, time()+60*60*7);
                        setcookie('destination', $dt, time()+60*60*7);
                        setcookie('traveltime', $traveltime, time()+60*60*7);
                    }
                    echo $searchdate;
                    //table is shown below when button is pressed.
                    echo "<table class=header style=margin-top:20px; margin-left:0px; align=center>
				<tr style=color:#333; align=center>
                    <th>Starting Point</th>  
                    <th>Destination</th>
                    <th>Date and Time</th>
                    <th>Image</th> 
                    </tr>";  
                    while($row = mysqli_fetch_array($query)){
                        //shows the data within the table 
                        $startingpoint=$row['startingpoint'];
                        $destination=$row['destination'];
                        $traveltime=$row['traveltime'];

                        echo "<tr>";
                        echo "<td>".$startingpoint."</td>";
                        echo "<td>".$destination."</td>";
                        echo "<td>".$traveltime."</td>";
                        echo '<td><img src="getImage.php?id='.$row['id'].'" alt="'. $row['alt']. '" title="'. $row['name'].'"width="175" height="200"/><td/>';
                        echo "<td><a href=\"searchDetails.php?id=$row[id]&&sp=$row[startingpoint]&&ds=$row[destination] &&dy=$row[days]&&cst=$row[traveltime]\" onClick=content(this)>View details</a></td>"; 
                    }
                    echo "</table>";
                }
            }
            ?>
            <script>
                function content(elem) 
                {
                    //javascript that shows a alert message
                    elem.style.backgroundColor = "red";
                    window.alert('Are you sure you want to view more details on this?');
                }
            </script>
        </body>
    </html>
    <div class="header">
        <?php echo $output; ?>
    </div>