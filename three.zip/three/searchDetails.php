<?php
session_start();
if (isset($_SESSION['username'])) {
    header('Location: search.php');
    //if there is a username logged in, it goes straight to the search..
} else if(!(isset($_SESSION['username']))) {
    header('Location: login.php');
    //if the username is not logged in, it goes straight to the login for them to log in first.
}
?>