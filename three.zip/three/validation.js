  function validationRegister()
        {
        var validation = true;
        var message = 'Please correct the following:\n';

        if (document.getElementById("username").value=="")
        {
            message = message + '* Username is missing!\n';
            validation = false;
        }
        if (document.getElementById("password").value=="")
        {
            message = message + '* Password is missing!\n';
            validation = false;
        }
        if (document.getElementById("email").value=="")
        {
            message = message + '* Email is missing!\n';
            validation = false;
        }
        if (document.getElementById("captcha").value=="")
        {
            message = message + '* Captcha is missing!\n';
            validation = false;
        }
        if (validation === false)
        {
            window.alert(message);
        }
		
        return validation;
    }
          function validationLogin()
        {
        var validation = true;
        var message = 'Please correct the following:\n';

        if (document.getElementById("username").value=="")
        {
            message = message + '* Username is missing!\n';
            validation = false;
        }
        if (document.getElementById("password").value=="")
        {
            message = message + '* Password is missing!\n';
            validation = false;
        }
        if (validation === false)
        {
            window.alert(message);
        }
		
        return validation;
    }
  function validationLogin()
        {
        var validation = true;
        var message = 'Please correct the following:\n';

        if (document.getElementById("username").value=="")
        {
            message = message + '* Username is missing!\n';
            validation = false;
        }
        if (document.getElementById("password").value=="")
        {
            message = message + '* Password is missing!\n';
            validation = false;
        }
        if (validation === false)
        {
            window.alert(message);
        }
		
        return validation;
    }
  function validationAddPost()
        {
        var validation = true;
        var message = 'Please correct the following:\n';

      
        if (document.getElementById("startingpoint").value=="")
        {
            message = message + '* Starting Point is missing!\n';
            validation = false;
        }
             if (document.getElementById("destination").value=="")
        {
            message = message + '* Destination is missing!\n';
            validation = false;
        }
        if (document.getElementById("days").value=="")
        {
            message = message + '* Days is missing!\n';
            validation = false;
        } if (document.getElementById("lift").value=="")
        {
            message = message + '* Provide Lift or Obtain Lift is missing!\n';
            validation = false;
        }
        if (document.getElementById("cost").value=="")
        {
            message = message + '* Cost is missing!\n';
            validation = false;
        } if (document.getElementById("car").value=="")
        {
            message = message + '* Car is missing!\n';
            validation = false;
        }
        if (validation === false)
        {
            window.alert(message);
        }
		
        return validation;
    }