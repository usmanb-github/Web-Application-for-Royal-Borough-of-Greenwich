<?php
include'include/functions.php';
include'include/connection.php';
ob_start();
if(isset($_SESSION['username'])) {
    header('Location: index.php');
}
if ($_POST['loginBtn']) {
    //gets the username and password using Post
    $username = $_POST['username'];
    $password = $_POST['password'];
    //Selects where the username has confirmed it from the database and uses SQL Injection
    $stmt = $database->prepare("SELECT confirm FROM users WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    // $sql = mysqli_query($database, "SELECT confirm FROM users WHERE username='$username'");
    //	$result = mysqli_fetch_assoc($sql);
    $rows = $row['confirm'];


    if(empty( $_POST['username'] && $_POST['password']))
    {
        $errormessage = "Please fill in your details.";
    } else {
        if(isset($_POST['rememberme']) && $_POST['cookielaw']) {
            setcookie('user', $username, time()+60*60*7);
            //puts a cookie in for the username
        } 
        //gets all the data and verifies it.
        $results = mysqli_query($database, "SELECT password FROM users WHERE username='$username'");
        $row = mysqli_fetch_array($results);
        $password = $_POST['password'];
        $passwordRow = $row['password'];
        $passwordVerify = password_verify($password, $passwordRow); //added security for the password verifies the password
        // used from http://php.net/manual/en/function.password-verify.php. Adapted accordingly.
        $query = "SELECT * FROM users WHERE username='$username'";
        $results = mysqli_query($database, $query);
        if ((mysqli_num_rows($results) == 1) && password_verify($password, $passwordRow))  { //checks how many rows and checks it
            $_SESSION['username'] = $username;
            header("Location: index.php");		
        } else {
            $errormessage = "The username and password do not match our system. Try again";
        } 
    }
    if ($rows != 1){	
        //if the count is 0, it refers the user to the Email Verification page and sends an code email to verify the account again.
        $charArray = array('a','b','c','d','e','f','g','h','j','k','m','n','p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','G','H','J','K','L','M','N','P','Q','R','T','U','V','W','X','Y','Z','2','3','4','6','7','8','9');
        shuffle($charArray);
        $confirmationCode = $charArray[0];
        for ($i=1; $i<5; $i++) $confirmationCode .= '' . $charArray[$i];
        $results = mysqli_query($database, "SELECT password FROM users WHERE username='$username'");
        $row = mysqli_fetch_array($results);
        $password = $_POST['password'];
        $passwordRow = $row['password'];
        $passwordVerify = password_verify($password, $passwordRow);

        if ((mysqli_num_rows($results) == 1) && password_verify($password, $passwordRow))  {
            $result = mysqli_query($database, "SELECT * FROM users WHERE username ='$username'");
            if ($row = mysqli_fetch_array($result)) {
                $email = $row['email'];
                $_SESSION['username'] = $_POST['username'];
                $_SESSION['code'] = $confirmationCode;

                $message = "Hello,
				 Please use the code below to verify email address and activate account.
				 Username: $username 
				 Activation Code: $confirmationCode
				 Thank you,
				 Greenwich Borough";
                mail($email ,'Account activation code', $message, "From: ub2232e@greenwich.ac.uk");

                header('Location: regconfirm.php');
            }
        }
        //one last error is sort out the seperation of password and 1...
    }
}
?>

<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb">
    <!-- Navigation Bar -->
    <div class="navigation">
        <a class="home" href="navigation.php">Home</a>
        <a class="login" href="login.php">Login</a>
        <a class="register" href="register.php">Register</a>
    </div>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <!-- used from https://www.w3schools.com/html/html_responsive.asp -->
        <title>Login</title>
        <link rel="stylesheet" type="text/css" href="style.css">
        <script type="text/javascript" src="validation.js"></script>
    </head>
    <body>
        <!-- HTML details are all below -->
        <div class="header">
            <h2>Login</h2>
        </div>
        <form method="post" action="login.php" onSubmit="validationLogin()">
            <div class="container">
                <div class="input-group">
                    <label>Username</label>
                    <input type="text" name="username" id="username" value="<?php $userCookie = $_COOKIE['user']; echo $userCookie;?>" placeholder="Enter Username">
                </div>
                <div class="input-group">
                    <label>Password</label>
                    <input type="password" name="password" id="password" value="<?php if(isset($_POST["password"])) echo $_POST["password"]; ?>" 
                           placeholder="Enter Password">
                </div>
                <div class="input-group">
                    <input type=radio name="rememberme" value="rememberme"><label>Remember Me?</label>
                    </div>
                   <div class="input-group">
                 <input type="checkbox" name="cookielaw"><label>This site uses cookies. Regulations require us to gain your consent before continuing for this page. Tick this to accept.</label>
                </div>
                <div class="input-group">
                    <p>
                        Not registered yet? <a href="register.php">Sign up here</a>
                    </p>
                </div>
             
                <div class="input-group">
                    <input type="submit"  name="loginBtn" value="Login">
                </div>
                <?php echo $errormessage; ?>
            </div>
        </form>
    </body>
</html>