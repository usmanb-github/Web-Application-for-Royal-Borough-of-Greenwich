<?php
include'include/connection.php';
include'include/functions.php';
//gets the Image. This was used from http://stuweb.cms.gre.ac.uk/~ha07/web/PHP/imageUpload.html

$query = 'SELECT type,img FROM members WHERE id="' . $_GET['id'] . '"';
$result = mysqli_query($database, $query);
$row = mysqli_fetch_assoc($result);
header('Content-Type: ' . $row['type']);
echo $row['img'];
?>
