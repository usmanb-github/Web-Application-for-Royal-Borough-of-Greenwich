<?php
//deletes query when used
include'include/functions.php';
include'include/connection.php';
$id = $_GET['id'];
$sql = "DELETE FROM members WHERE id='$id'";
if(mysqli_query($database, $sql)) {
    header("Location: index.php");
    exit;
}
?>