<?php
//deletes image where it updates it to null
include'include/functions.php';
include'include/connection.php';
$id = $_GET['id'];
$null = null;
$sql = "UPDATE members SET type=null, name=null, alt=null, img=null WHERE id=$id";
if(mysqli_query($database, $sql)) {
    header("Location: index.php");
    exit;
}
?>