<?php 
error_reporting(E_ERROR);
session_start();
$_SESSION['id'] = $_GET['id'];
//if theres no username session; the user gets referred back to the Login. Much more secure.

if(!($_SESSION['username'])) {
    header("Location: login.php");
}
//Once the user logs out, the session is destroyed and referred back to the Login.
if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("Location: login.php");
}
?>
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb">

    <head>
        <!-- navigation bar-->
        <div class="navigation">
            <a class="home" href="index.php">Home</a>
            <a class="logout" href="index.php?logout='1'">Logout</a>
            <a class="contactus" href="ContactUs.php">Contact Us</a>
            <a class="addTable" href="addTable.php">Add Post</a>
            <a class="viewpost" href="search.php">Search Posts</a>
        </div>
        <title>Image Upload</title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>    
    <body>
        <form action="imageUpload.php?id=<?php $id = $_GET['id']; echo $id; ?>" method="post" enctype="multipart/form-data">
            <fieldset>
                        <!-- HTML details are all below -->
                <div class="container">
                    <div class="header">
                        <legend>Image Upload</legend>
                    </div>
                    <div class="input-group">	
                        <input type="hidden" name="id" value='<?php $id = $_GET['id']; echo $id;
                               ?>' readonly="readonly">
                    </div>	
                    <div class="input-group">
                        <label for="userFile">Small image to upload: </label>
                        <input type="file" size="40" name="userFile" id="userFile"/>
                    </div>
                    <br>
                    <div class="input-group">
                        <label for="altText">Description of image</label>
                        <input type="text" size="60" name="altText" id="altText"/>
                    </div>
                    <div class="input-group">
                        <input type="submit" name="uploadfile" value="Upload File" />
                    </div>
                </div>
            </fieldset>
            <div class="header" style="height:80px;
                                       width: 250px; padding-left:60px;">
                <h1>Uploading Images to MySQL</h1>
            </div>
        </form>
    </body>
</html>

<?php
include'include/connection.php';
//image upload was used from http://stuweb.cms.gre.ac.uk/~ha07/web/PHP/imageUpload.html
if ( !isset($_FILES['userFile']['type']) ) {
    die('<p>No image submitted</p></body></html>');
}
?>
You submitted this file:<br /><br />
Temporary name: <?php echo $_FILES['userFile']['tmp_name'] ?><br />
Original name: <?php echo $_FILES['userFile']['name'] ?><br />
Size: <?php echo $_FILES['userFile']['size'] ?> bytes<br />
Type: <?php echo $_FILES['userFile']['type'] ?></p>
<?php
    include'include/functions.php';
include'include/connection.php';
// Validate uploaded image file
if ( !preg_match( '/gif|png|x-png|jpeg/', $_FILES['userFile']['type']) ) {
    die('<p>Only browser compatible images allowed</p></body></html>');
} else if ( strlen($_POST['altText']) < 4 ) {
    die('<p>Please provide meaningful alternate text</p></body></html>');
} else if ( $_FILES['userFile']['size'] > 16384 ) {
    die('<p>Sorry file too large</p></body></html>');
    // Connect to database
} else if ( !($database) ) {
    die('<p>Error connecting to database</p></body></html>');
    // Copy image file into a variable
} else if ( !($handle = fopen ($_FILES['userFile']['tmp_name'], "r")) ) {
    die('<p>Error opening temp file</p></body></html>');
} else if ( !($image = fread ($handle, filesize($_FILES['userFile']['tmp_name']))) ) {
    die('<p>Error reading temp file</p></body></html>');
} else {
    fclose ($handle);
    $image = mysqli_real_escape_string($database, $image);
    $alt = $_POST['altText'];
    $imageName = $_FILES['userFile']['name'];
    $imageType = $_FILES['userFile']['type'];
    $id = mysqli_real_escape_string($database, trim($_POST['id']));

    if (!(mysqli_query($database, "UPDATE members SET type='$imageType', name='$imageName', alt='$alt', img='$image' WHERE id=$id"))) {
        die('<p>Error writing image database</p></body></html>');
    } else {
        die('<p>Image successfully copied to database</p></body></html>');
    }
}
?>