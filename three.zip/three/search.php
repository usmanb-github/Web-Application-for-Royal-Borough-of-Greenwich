<?php 
include'include/connection.php';
include'include/functions.php';
//if theres no username session; the user gets referred back to the Login. Much more secure.
if(!($_SESSION['username'])) {
    header("Location: login.php");
}
//Once the user logs out, the session is destroyed and referred back to the Login.
if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("Location: login.php");
} 
?>
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb">

    <head>
        <!-- navigation bar-->
        <div class="navigation">
            <a class="home" href="index.php">Home</a>
            <a class="logout" href="index.php?logout='1'">Logout</a>
            <a class="contactus" href="ContactUs.php">Contact Us</a>
            <a class="addTable" href="addTable.php">Add Post</a>
            <a class="viewpost" href="search.php">Search Posts</a>
        </div>
        <title>View Posts</title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
        <form action="search.php" method="post">
            <div class="header">
                <h2>View Posts</h2>
                <h4> These are all the posts that have been posted by other users.</h4>
            </div>
      <div class="container">
                  <!-- All the inputs that are used, the style is used here too.r-->
                    <div class="input-group">
                        <label> Starting Point:-  </label>
                        <input type="text" name="startingpoint" value="<?php $userCookie = $_COOKIE['startingpoint']; echo $userCookie;?>" placeholder="e.g. London ">
                    </div>
                    <div class="input-group">
                        <label> Destination:-  </label>
                        <input type="text" name="destination" value="<?php $userCookie = $_COOKIE['destination']; echo $userCookie;?>"placeholder="e.g. Manchester">
                    </div>
                    <div class="input-group">
                        <label> Date and Time:-  </label>
                        <input type="datetime-local" name="traveltime" value="<?php $userCookie = $_COOKIE['traveltime']; echo $userCookie;?>">
                    </div>
                    <div class="input-group">
                        <input type="submit"  name="search" value="Search">
                        <?php echo $output; ?>
                    </div>
                </div>
                <div style="margin-top:250px; 
                            margin-left:10px; text-align: center;">
                    <h3> Results</h3>
                </div>
            </form>


            <?php
            if(isset($_POST['search'])){
                //this gets all the information that is typed.
                $sp = $_POST['startingpoint'];
                $dt = $_POST['destination'];
                $ds = $_POST['days'];
                $traveltime = $_POST['traveltime'];
                //uses preg replace to do all the filtering
                $searchsp=preg_replace("#[^0-9a-z]#i"," ", $sp);
                $searchdt=preg_replace("#[^0-9a-z]#i"," ", $dt);
                $searchcst=preg_replace("#[^0-9a-z]#i"," ", $traveltime);
                
                //puts it in the query to match the database
                $query = mysqli_query($database,'SELECT * FROM members WHERE startingpoint LIKE "%'.$searchsp.'%" AND destination LIKE "%'.$searchdt.'%" AND days LIKE "%'.$searchds.'%" AND traveltime LIKE "%'.$$traveltime.'%" AND type IS NOT NULL');
                $count = mysqli_num_rows($query);
                //counts if there is 0 rows.
                if ($count == 0) {
                    $output = "There was no search result.";
                }
                else {
                    //table is shown once the search button is pressed.
                    echo "<table class=header style=margin-top:20px; margin-left:0px; align=center>
				<tr style=color:#333; align=center>
                <td>ID</td>
                <td>Usernames</td>
                <td>Starting Point</td>
                <td>Destination</td>
                <td>Date and Time</td>
                <td>Days</td>
                <td>Lift</td>
                <td>What sort of cost sharing do you have in mind?</td>
                <td>What sort of car do you have?</td>
                <td>Image</td>";
                    //all the details using the database is shown below.
                    while($row = mysqli_fetch_array($query)) {
                         $id = $row['id'];
                        $username=$row['username'];
                        $startingpoint=$row['startingpoint'];
                        $destination=$row['destination'];
                        $traveltime=$row['traveltime'];
                        $days=$row['days'];
                        $lift=$row['lift'];
                        $cost=$row['cost'];
                        $car=$row['car'];
                        echo "<tr>";
                        echo "<td>".$id."</td>";
                        echo "<td>".$username."</td>";
                        echo "<td>".$startingpoint."</td>";
                        echo "<td>".$destination."</td>";
                        echo "<td>".$traveltime."</td>";
                        echo "<td>".$days."</td>";
                        echo "<td>".$lift."</td>";
                        echo "<td>".$cost."</td>";
                        echo "<td>".$car."</td>";
                        echo '<td><img src="getImage.php?id='.$row['id'].'" alt="'. $row['alt']. '" title="'. $row['name'].'"width="175" height="200"/><td/>';
                            
                    }
                    echo "</table>";
                }
            }
            ?>
        </body>
    </html>
<div class="header">
        <?php //output is shown here...    
echo $output; ?>
    </div>